package com.duda.caloriafit

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.*
import androidx.compose.material3.*
import com.duda.caloriafit.ui.theme.MainActivityTheme
import java.util.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MainActivityTheme {
                Surface(color = MaterialTheme.colorScheme.background) {
                    var telaAtual by remember { mutableStateOf("login") }
                    var calorias by remember { mutableStateOf(0) }
                    var dadosSemana by remember { mutableStateOf(List(7) { 0 }) }

                    when (telaAtual) {
                        "login" -> LoginScreen(
                            navToHome = { telaAtual = "dashboard" }
                        )

                        "dashboard" -> DashboardScreen(
                            irParaCalorias = { telaAtual = "calorias" },
                            irParaHistorico = { telaAtual = "historico" },
                            onLogout = { telaAtual = "login" }
                        )

                        "calorias" -> CaloriaScreen(
                            calorias = calorias,
                            onAdicionarRefeicao = { kcal ->
                                val novaLista = dadosSemana.toMutableList()
                                novaLista[getDiaSemana()] += kcal
                                dadosSemana = novaLista
                                calorias += kcal
                            },
                            onVerDetalhado = {
                                telaAtual = "addrefeicao"
                            },
                            onVoltar = {
                                telaAtual = "dashboard"
                            }
                        )

                        "addrefeicao" -> AddMealScreen(
                            onSave = { _, kcal ->
                                val novaLista = dadosSemana.toMutableList()
                                novaLista[getDiaSemana()] += kcal
                                dadosSemana = novaLista
                                calorias += kcal
                                telaAtual = "calorias"
                            },
                            onBack = {
                                telaAtual = "calorias"
                            }
                        )

                        "historico" -> HistoricoSemanalScreen(
                            dadosSemana = dadosSemana,
                            onVoltar = {
                                telaAtual = "dashboard"
                            }
                        )
                    }
                }
            }
        }
    }

    // Retorna o índice do dia atual da semana (segunda = 0, ..., domingo = 6)
    private fun getDiaSemana(): Int {
        val calendar = Calendar.getInstance()
        return when (calendar.get(Calendar.DAY_OF_WEEK)) {
            Calendar.SUNDAY -> 6
            Calendar.MONDAY -> 0
            Calendar.TUESDAY -> 1
            Calendar.WEDNESDAY -> 2
            Calendar.THURSDAY -> 3
            Calendar.FRIDAY -> 4
            Calendar.SATURDAY -> 5
            else -> 0
        }
    }
}
