package com.duda.caloriafit

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "habitos")

object DataStoreUtils {
    private val HABITOS_KEY = stringSetPreferencesKey("habitos_set")

    suspend fun salvarHabito(context: Context, habito: String) {
        context.dataStore.edit { prefs ->
            val habitos = prefs[HABITOS_KEY]?.toMutableSet() ?: mutableSetOf()
            habitos.add(habito)
            prefs[HABITOS_KEY] = habitos
        }
    }

    suspend fun carregarHabitos(context: Context): Set<String> {
        val prefs = context.dataStore.data.map { it[HABITOS_KEY] ?: emptySet() }
        return prefs.first()
    }
}
